clc;
close all;

%% Given Values
pow_hp = 50;
pow_kw = 37.285;
B = 0.00001; % Rotor Damping
Vb = 460; % Base voltage (rms)
P = 4; % Number of poles
w_base = 377; % Base speed (rad/s)
rs = 0.087; % Stator resistance (Ohms)
Xlrp = 0.302; % Referred rotor leakage reactance
rrp = 0.228; % Referred rotor resistance
Xls = 0.302; % Stator leakage reactance
wt = 377; % Test frequency (rad/s)
XM = 13.8; % Magnetizing reactance
J = 1.662; % Inertia (kg.m^2)
wb = 377; % Base frequency

%% Simulink Calculations
Lls = Xls / wt;
Llrp = Xlrp / wt;
LM = XM / wt;
Lms = 0.0244;
Lmrp = Lms;

%% Simulink Output Data
t = out.ias.time;
vas = out.vas.signals.values;
vbs = out.vbs.signals.values;
vcs = out.vcs.signals.values;
ias = out.ias.signals.values;
ibs = out.ibs.signals.values;
ics = out.ics.signals.values;
iarp = out.iarp.signals.values;
ibrp = out.ibrp.signals.values;
icrp = out.icrp.signals.values;
Te = out.Te.signals.values;
wr = out.wr.signals.values;
theta_r = out.theta_r.signals.values;
rotor_speed = out.rotor_speed.signals.values; % RPM

%% Basic Calculations and Plots

%% Plot 1: Stator Phase Currents with Peak i_a
[peak_ias, idx_ias] = max(abs(ias));
figure;
plot(t, ias,'LineWidth', 2); hold on;
plot(t, ibs,'LineWidth', 2);
plot(t, ics,'LineWidth', 2);
plot(t(idx_ias), ias(idx_ias), 'v', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
text(t(idx_ias), ias(idx_ias)+2, sprintf('    %.2f A', peak_ias), ...
     'FontSize', 10, 'FontWeight', 'bold');
grid on;
xlabel('Time (s)', 'FontSize', 12);
ylabel('Stator Current (A)', 'FontSize', 12);
legend('i_a', 'i_b', 'i_c', 'Location', 'best');
title('Stator Phase Currents', 'FontSize', 14);

%% Plot 2: Rotor Phase Currents with Peak i_{r,a}
figure;
plot(t, iarp,'LineWidth', 2); hold on;
plot(t, ibrp,'LineWidth', 2);
plot(t, icrp,'LineWidth', 2);

grid on;
xlabel('Time (s)', 'FontSize', 12);
ylabel('Referred Rotor Current (A)', 'FontSize', 12);
legend('i_{r,a}', 'i_{r,b}', 'i_{r,c}', 'Location', 'best');
title('Rotor Phase Currents', 'FontSize', 14);

%% Plot 3: Torque vs Rotor Speed with Max Torque
[max_Te, idx_Te] = max(Te);
figure;
plot(rotor_speed, Te, 'b-', 'LineWidth', 2); hold on;
yline(0,'--');
plot(rotor_speed(idx_Te), max_Te, 'v', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
text(rotor_speed(idx_Te), max_Te + 1, sprintf('   %.2f N·m', max_Te), ...
     'FontSize', 10, 'FontWeight', 'bold');
grid on;
xlabel('Speed (RPM)', 'FontSize', 12);
ylabel('Torque (N\cdotm)', 'FontSize', 12);
title('Torque vs Rotor Speed', 'FontSize', 14);

%% Plot 4: Torque vs Time with Max Torque
figure;
plot(t, Te, 'k-', 'LineWidth', 2); hold on;
yline(0,'--');
plot(t(idx_Te), max_Te, 'v', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
text(t(idx_Te), max_Te + 1, sprintf('   %.2f N·m', max_Te), ...
     'FontSize', 10, 'FontWeight', 'bold');
grid on;
xlabel('Time (s)', 'FontSize', 12);
ylabel('Torque (N\cdotm)', 'FontSize', 12);
title('Torque during Free Acceleration', 'FontSize', 14);


%% Advanced Analysis

% In-rush current (max stator current at start)
inrush = max(abs(ias));

% Peak-to-peak torque
peak2peak_Te = max(Te) - min(Te);

% Instantaneous Power Calculations
[~, idx_peak] = max(Te);
t_peak = t(idx_peak);
P_stator = 3 * rs * (ias.^2 + ibs.^2 + ics.^2);
P_rotor = 3 * rrp * (iarp.^2 + ibrp.^2 + icrp.^2);
P_shaft = Te .* wr;
P_inst = vas.*ias + vbs.*ibs + vcs.*ics;



%% Printing the results nicely
fprintf('\n========================================\n');
fprintf('Simulation Results:\n');
fprintf('========================================\n');

fprintf('II) 1) In-rush Current (Phase A): %.2f A\n', inrush);
fprintf('II) 2) Peak-to-Peak Torque during Start-up: %.2f N.m\n', peak2peak_Te);

fprintf('\n II) 3) \nAt Peak Torque (t = %.4f s):\n', t_peak);
fprintf('  a) - Stator Power Dissipated: %.2f W\n', P_stator(idx_peak));
fprintf('  b) - Rotor Power Dissipated: %.2f W\n', P_rotor(idx_peak));
fprintf('  c) - Shaft Power: %.2f W\n', P_shaft(idx_peak));
fprintf('  d) - Instantaneous Input Power: %.2f W\n', P_inst(idx_peak));

fprintf('========================================\n');

% pull-out torque loading: 